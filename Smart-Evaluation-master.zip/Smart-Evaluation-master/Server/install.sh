npm install --save express mongoose express-validator config cryptr
npm install --save-dev nodemon morgan