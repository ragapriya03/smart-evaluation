import React from 'react';
import Table from '../Layouts/Results/Tabel';

const Show = ({ details, history }) => {
  return <Table details={details} history={history} />;
};

export default Show;
